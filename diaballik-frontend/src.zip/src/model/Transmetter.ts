import {Injectable} from '@angular/core';

@Injectable()
export class Transmetter {
  static data: any;
}
