export enum PlateauType {
  Standard = 'PlateauStandard',
  Random = 'PlateauRandomBall',
  Enemy = 'PlateauEnemyAmongUs',
}
